function execute() {
    return Response.success([
        {title: "Hot", input: "https://buondua.com/hot/", script: "gen.js"},
        {title: "Coser", input: "buondua.com/tag/cosplay-10688", script: "gen.js"},
    ]);
}