function execute() {
    return Response.success([
        {title: "Home",
         input: "https://buondua.com"}
    ]);
}