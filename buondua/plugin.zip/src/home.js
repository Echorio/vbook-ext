function execute() {
    return Response.success([
        {title: "Home", input: "https://buondua.com", script: "gen.js"}

    ]);
}