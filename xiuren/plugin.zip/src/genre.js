function execute() {
    return Response.success([
        {title: "Xiuren", input: "https://xiuren.biz/category/xiuren/", script: "gen.js"},
        {title: "Ugirls App", input: "https://xiuren.biz/category/ugirls/", script: "gen.js"},
        {title: "FeiLin", input: "https://xiuren.biz/category/feiLin/", script: "gen.js"},
        {title: "MiStar", input: "https://xiuren.biz/category/mistar/", script: "gen.js"},
        {title: "MyGirl", input: "https://xiuren.biz/category/MyGirl/", script: "gen.js"},
        {title: "HuaYang", input: "https://xiuren.biz/category/HuaYang/", script: "gen.js"},
        {title: "IMISS", input: "https://xiuren.biz/category/IMISS/", script: "gen.js"},
        {title: "MFStar", input: "https://xiuren.biz/category/MFStar/", script: "gen.js"},
        {title: "MiiTao", input: "https://xiuren.biz/category/MiiTao/", script: "gen.js"},
        {title: "XiaoYu", input: "https://xiuren.biz/category/XiaoYu/", script: "gen.js"},
        {title: "YouMi", input: "https://xiuren.biz/category/YouMi/", script: "gen.js"},
        {title: "DJAWA", input: "https://xiuren.biz/category/DJAWA/", script: "gen.js"},
        {title: "Hot Girl", input: "https://xiuren.biz/category/Hot-Girl/", script: "gen.js"}
    ]);
}