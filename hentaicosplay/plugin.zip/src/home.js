function execute() {
    return Response.success([
        {title: "Ranking", input: "https://hentai-cosplays.com/ranking/", script: "gen.js"}

    ]);
}